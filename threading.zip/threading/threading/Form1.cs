﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace threading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Thread othreadone = new Thread(()=>work("thread1"));
            Thread othreadtwo = new Thread(() => work("thread2"));
            othreadone.Start();
            othreadtwo.Start();
            work("nothread");
        }
        public static void work(string str)
        {
            MessageBox.Show("I am working in" + str);
        }
    }
}
